
namespace ParamsArrays
{
	using System;

	class Util
	{
		// to do
	}
}