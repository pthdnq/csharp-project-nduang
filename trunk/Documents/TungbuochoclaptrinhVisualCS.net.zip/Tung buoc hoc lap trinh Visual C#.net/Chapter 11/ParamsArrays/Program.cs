using System;

namespace ParamsArrays
{
	class Program
	{
		static void Entrance()
		{
			// to do		
		}

		static void Main()
		{
			try
			{
				Entrance();
			}
			catch (Exception caught)
			{
				Console.WriteLine("Exception: {0}", caught.Message);
			}
		}
	}
}
