using System;

namespace StructsAndEnums
{
	// to do
}