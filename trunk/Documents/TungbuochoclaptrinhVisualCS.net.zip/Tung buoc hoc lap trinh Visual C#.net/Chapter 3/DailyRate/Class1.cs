	using System;

namespace DailyRate
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		static void Main(string[] args)
		{
			(new Class1()).run();
		}

		public void run()
		{

		}
	}
}
