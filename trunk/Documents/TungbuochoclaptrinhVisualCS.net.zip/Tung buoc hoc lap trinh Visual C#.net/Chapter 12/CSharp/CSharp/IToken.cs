namespace CSharp
{
	interface IToken
	{
		string ToString();
	}
}
