namespace CSharp
{
	interface IVisitableToken : IVisitable, IToken
	{
	}
}
