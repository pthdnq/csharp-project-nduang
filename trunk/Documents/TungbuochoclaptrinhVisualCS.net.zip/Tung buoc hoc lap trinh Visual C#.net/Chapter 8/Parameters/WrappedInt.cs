
namespace Parameters
{
	class WrappedInt
	{
		// to do
	}
}

