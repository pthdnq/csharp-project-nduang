using System;

namespace Parameters
{
	class Pass
	{
		// to do
	}
}