
namespace Parameters
{
	class WrappedInt
	{
		public int Number;
	}
}

