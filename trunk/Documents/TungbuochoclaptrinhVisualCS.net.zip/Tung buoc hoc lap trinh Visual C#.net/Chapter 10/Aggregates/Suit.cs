
namespace Aggregates
{
	enum Suit { Clubs, Diamonds, Hearts, Spades }
}