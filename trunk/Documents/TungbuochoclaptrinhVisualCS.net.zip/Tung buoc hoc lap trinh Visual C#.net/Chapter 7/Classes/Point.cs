using System;

namespace Classes
{
	/// <summary>
	/// Summary description for Point.
	/// </summary>
	class Point
	{
		// to do
		public Point()
		{
			x=0;
			y=0;
		}
		public Point(int initialX, int initialY)
		{
			x=initialX; 
			y=initialY;
		}
		public double distanceTo(Point other)
		{
			int xDiff=x-other.x ;
			int yDiff=y-other.y ;
			return Math.Sqrt (xDiff*xDiff+yDiff*yDiff);
		}
		private int x,y;
	}

	class Application
	{
		static void Entrance()
		{
			Point origin=new Point(); 
			Point bottomRight =new Point (600,800);
			double distance=origin.distanceTo (bottomRight);
			Console.WriteLine ("Distance is :{0}",distance);
		}
		
		static void Main(string[] args)
		{
			try
			{
				Entrance();
			}
			catch (Exception caught)
			{
				Console.WriteLine(caught.Message);
			}
		}
	}
}
