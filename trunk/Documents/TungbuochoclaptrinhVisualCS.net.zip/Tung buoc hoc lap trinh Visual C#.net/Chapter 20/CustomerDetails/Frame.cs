using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CustomerDetails
{
	/// <summary>
	/// Summary description for Frame.
	/// </summary>
	public class Frame : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ImageList imageList;
		private System.Windows.Forms.ToolBar toolBar;
		private System.Windows.Forms.ToolBarButton newButton;
		private System.Windows.Forms.ToolBarButton saveButton;
		private System.Windows.Forms.MainMenu mainMenu;
		private System.Windows.Forms.MenuItem fileItem;
		private System.Windows.Forms.MenuItem newItem;
		private System.Windows.Forms.MenuItem saveItem;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem exitItem;
		private System.Windows.Forms.MdiClient mdiClient1;
		private System.Windows.Forms.StatusBar statusBar;
		private System.ComponentModel.IContainer components;

		public Frame()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Frame));
			this.saveButton = new System.Windows.Forms.ToolBarButton();
			this.mainMenu = new System.Windows.Forms.MainMenu();
			this.fileItem = new System.Windows.Forms.MenuItem();
			this.newItem = new System.Windows.Forms.MenuItem();
			this.saveItem = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.exitItem = new System.Windows.Forms.MenuItem();
			this.newButton = new System.Windows.Forms.ToolBarButton();
			this.toolBar = new System.Windows.Forms.ToolBar();
			this.imageList = new System.Windows.Forms.ImageList(this.components);
			this.mdiClient1 = new System.Windows.Forms.MdiClient();
			this.statusBar = new System.Windows.Forms.StatusBar();
			this.SuspendLayout();
			// 
			// saveButton
			// 
			this.saveButton.ImageIndex = 1;
			this.saveButton.ToolTipText = "Save customer";
			// 
			// mainMenu
			// 
			this.mainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.fileItem});
			// 
			// fileItem
			// 
			this.fileItem.Index = 0;
			this.fileItem.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.newItem,
																					 this.saveItem,
																					 this.menuItem4,
																					 this.exitItem});
			this.fileItem.Text = "&File";
			// 
			// newItem
			// 
			this.newItem.Index = 0;
			this.newItem.Text = "&New";
			this.newItem.Click += new System.EventHandler(this.newClick);
			// 
			// saveItem
			// 
			this.saveItem.Index = 1;
			this.saveItem.Text = "&Save";
			this.saveItem.Click += new System.EventHandler(this.saveClick);
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 2;
			this.menuItem4.Text = "-";
			// 
			// exitItem
			// 
			this.exitItem.Index = 3;
			this.exitItem.Text = "E&xit";
			this.exitItem.Click += new System.EventHandler(this.exitClick);
			// 
			// newButton
			// 
			this.newButton.ImageIndex = 0;
			this.newButton.ToolTipText = "New customer";
			// 
			// toolBar
			// 
			this.toolBar.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																					   this.newButton,
																					   this.saveButton});
			this.toolBar.DropDownArrows = true;
			this.toolBar.ImageList = this.imageList;
			this.toolBar.Name = "toolBar";
			this.toolBar.ShowToolTips = true;
			this.toolBar.Size = new System.Drawing.Size(584, 25);
			this.toolBar.TabIndex = 0;
			this.toolBar.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.toolButtonClick);
			// 
			// imageList
			// 
			this.imageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.imageList.ImageSize = new System.Drawing.Size(16, 16);
			this.imageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList.ImageStream")));
			this.imageList.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// mdiClient1
			// 
			this.mdiClient1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.mdiClient1.Location = new System.Drawing.Point(0, 25);
			this.mdiClient1.Name = "mdiClient1";
			this.mdiClient1.TabIndex = 1;
			// 
			// statusBar
			// 
			this.statusBar.Location = new System.Drawing.Point(0, 377);
			this.statusBar.Name = "statusBar";
			this.statusBar.Size = new System.Drawing.Size(584, 20);
			this.statusBar.TabIndex = 2;
			// 
			// Frame
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(584, 397);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.statusBar,
																		  this.toolBar,
																		  this.mdiClient1});
			this.IsMdiContainer = true;
			this.Menu = this.mainMenu;
			this.Name = "Frame";
			this.Text = "Customer Maintenance";
			this.ResumeLayout(false);

		}
		#endregion
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Frame());
		}

		private void displayCustomerForm()
		{
			CustomerForm cf = new CustomerForm();
			cf.MdiParent = this;
			cf.Show();
		}

		private void saveCustomerForm()
		{
			statusBar.Text = "Customer saved";
		}

		private void toolButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
			if (e.Button.Equals(newButton))
			{
				displayCustomerForm();
			}
			
			if (e.Button.Equals(saveButton))
			{
				saveCustomerForm();
			}
		}

		private void newClick(object sender, System.EventArgs e)
		{
			displayCustomerForm();
		}

		private void saveClick(object sender, System.EventArgs e)
		{
			saveCustomerForm();
		}

		private void exitClick(object sender, System.EventArgs e)
		{
			Application.Exit();
		}
	}
}
