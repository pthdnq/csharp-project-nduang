Public Class Form1

    'Item is filled either manually or from database 
    Dim lst As New List(Of String)

    'AutoComplete collection that will help to filter keep the records.
    Dim MySource As New AutoCompleteStringCollection()

    Private Sub Form1_Load(ByVal sender As System.Object, _
     ByVal e As System.EventArgs) Handles MyBase.Load

        'Manually added some items
        lst.Add("apple")
        lst.Add("applle")
        lst.Add("appple")
        lst.Add("appplee")
        lst.Add("bear")
        lst.Add("pear")

        'Records binded to the AutocompleteStringCollection.
        MySource.AddRange(lst.ToArray)

        'this AutocompleteStringcollection binded to the textbox as custom
        'source.
        TextBox1.AutoCompleteCustomSource = MySource
        ''OR you can use this for combobox
        ''ComboBox1.AutoCompleteCustomSource = MySource

        'Auto complete mode set to suggest append so that it will sugesst one
        'or more suggested completion strings it has both �Suggest� and
        '�Append� functionality
        TextBox1.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        ''OR you can use this for combobox
        ''ComboBox1.AutoCompleteMode = AutoCompleteMode.SuggestAppend

        'Set to Custom source we have filled already
        TextBox1.AutoCompleteSource = AutoCompleteSource.CustomSource
        ''OR you can use this for combobox
        ''ComboBox1.AutoCompleteSource = AutoCompleteSource.CustomSource
    End Sub

    Private Sub TextBox1_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBox1.KeyDown
        If e.KeyCode = Keys.Enter Then   ' On enter I planned to add it the list
            If Not TextBox1.AutoCompleteCustomSource.Contains(TextBox1.Text) Then  ' If item not present already
                ' Add to the source directly
                TextBox1.AutoCompleteCustomSource.Add(TextBox1.Text)
            End If
        ElseIf e.KeyCode = Keys.Delete Then  ' On delete key i have planned to remove the entry
            ' remove item from source
            CType(TextBox1.AutoCompleteCustomSource, AutoCompleteStringCollection).Remove(TextBox1.Text)
            ' Clear textbox
            TextBox1.Clear()
        End If
    End Sub

    ''
    '' Uncomment the below event if you have also filled Combobox with the source
    '' mentioned in form_Load event, this will enable Addition and Deleteion of elements
    '' in combobox as well.
    ''
    'Private Sub ComboBox1_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles ComboBox1.KeyDown
    '    If e.KeyCode = Keys.Enter Then   ' On enter I planned to add it the list
    '        If Not ComboBox1.AutoCompleteCustomSource.Contains(ComboBox1.Text) Then  ' If item not present already
    '            ' Add to the source directly
    '            ComboBox1.AutoCompleteCustomSource.Add(TextBox1.Text)
    '        End If
    '    ElseIf e.KeyCode = Keys.Delete Then  ' On delete key i have planned to remove the entry
    '        ' remove item from source
    '        CType(ComboBox1.AutoCompleteCustomSource, AutoCompleteStringCollection).Remove(ComboBox1.Text)
    '        ComboBox1.Text = String.Empty
    '    End If
    'End Sub

End Class
